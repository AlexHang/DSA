Big Homework 2

Authors: Diana Scurtu 
	 Alex Hang

Exercise 1:

Input Method: the number of students, number of projects, and the names of the students and projects are read from the "txt.in" file, using fstream.

Data Structures used:	- 3 structs * proiect
				  * elev
 				  * camp
			- 1 class   * LinkedList (from the course)

Functionalities: 	* reading the data from the file, and creating the LinkedList of Students and Projects
			* printing the list
			* deletion of a student from the list	  
			* replacement of a project with another one
Exercise 2: 


Input Method: the number of streets and intersections  are read from the "streets.in" file, using fstream.

Data Structures used:	- 1 Graph representing the map of the streets

Approach: 
1) read the streets and intersections from the file, and create the graph.
2) check if the graph is Hamiltonian:
	IF TRUE		
		3) Find the Hamiltonian Cycle through the Graph
		4) Print the solution
	IF FALSE
		* Print a message


Exercise 3:

Input Method: the words are read from the "streets.in" file, using fstream.

Data Structures used:	- 1 Graph 
			- 1 List
			- 1 Stack
Approach: Topological Sort 

 
